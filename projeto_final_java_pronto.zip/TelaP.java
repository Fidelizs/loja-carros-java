public interface TelaP {
    void mostrarP();

    void deletarP();

    void listaDePessoasFisicas();
    
    void modificarP();

    void mostrarJ();

    void deletarJ();

    void listaDePessoasJuridicas();

    void modificarJ(); 
    
}