import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args) {
        int opcao = 0, subOpcao;

        Tela cadastroVeiculo = new CadastrarVeiculo();
        TelaP cadastroPessoa = new CadastrarPessoa1();

        Scanner scanf = new Scanner(System.in);

        System.out.println("Bem-vindos ao Mega Saldão de Carros!\n");

        List<String> opcoes = new ArrayList<>();
        opcoes.add("1 - Cadastro");
        opcoes.add("2 - Lista de Veículos.");
        opcoes.add("3 - Lista de Clientes.");
        opcoes.add("4 - Deletar dados.");
        opcoes.add("5 - Editar dados.");
        opcoes.add("6 - Sair.");

        while (opcao != 6) {
            try {
                System.out.println("\nMenu Principal:");
                for (String o : opcoes) {
                    System.out.println("- " + o);
                }

                System.out.println("\nEscolha uma opção: ");
                System.out.println("--------------------------");

                opcao = scanf.nextInt();
                scanf.nextLine();

                switch (opcao) {
                    case 1:
                        System.out.println("\n1 - Cadastro de Veículo.\n2 - Cadastro de Pessoa Física.\n3 - Cadastro de Pessoa Jurídica.\n4 - Voltar.\n");
                        System.out.println("Escolha uma opção:\n");
                        System.out.println("--------------------------");
                        subOpcao = scanf.nextInt();
                        scanf.nextLine();

                        switch (subOpcao) {
                            case 1:
                                
                                cadastroVeiculo.mostrar();
                                break;
                            case 2:
                                cadastroPessoa.mostrarP();
                                break;
                            case 3:
                                cadastroPessoa.mostrarJ();
                                break;
                            case 4:
                                System.out.println("Voltando ao menu principal...\n");
                                break;
                            default:
                                System.out.println("Opção inválida.\n");
                        }
                        break;

                    case 2:
                        cadastroVeiculo.listaDeVeiculos();
                        break;

                    case 3:
                        System.out.println("1 - Lista de Pessoas Físicas. \n2 - Lista de Pessoas Jurídicas. \n3 - Voltar.\n");
                        subOpcao = scanf.nextInt();
                        scanf.nextLine();

                        switch (subOpcao) {
                            case 1:
                               
                                cadastroPessoa.listaDePessoasFisicas();
                                break;
                            case 2:
                                 
                                cadastroPessoa.listaDePessoasJuridicas();
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opção inválida.\n");
                        }
                        break;

                    case 4:
                        System.out.println("--------------------------");
                        System.out.println("O que você deseja deletar?\n1 - Pessoa Física/Jurídica.\n2 - Veículos.");
                        subOpcao = scanf.nextInt();

                        switch (subOpcao) {
                            case 1:
                                System.out.println("--------------------------");
                                System.out.println("1 - Deletar Cadastro de Pessoas Físicas \n2 - Deletar Cadastro de Pessoas Jurídicas \n3 - Voltar\n");
                                subOpcao = scanf.nextInt();
                                scanf.nextLine();

                                switch (subOpcao) {
                                    case 1:
                                        cadastroPessoa.deletarP();
                                        break;
                                    case 2:
                                        cadastroPessoa.deletarJ();
                                        break;
                                    case 3:
                                        break;
                                    default:
                                        System.out.println("Opção inválida.\n");
                                }
                                break;

                            
                            case 2: 
                                cadastroVeiculo.deletar();
                                break;

                            default:
                                System.out.println("Opção inválida.\n");
                        }
                        break;

                    case 5:
                        System.out.println("--------------------------");
                        System.out.println("\nSelecione o que deseja editar.\n1 - Veículos.\n2 - Pessoas Físicas.\n3 - Empresas.\n4 - Voltar.\n");
                        subOpcao = scanf.nextInt();
                        scanf.nextLine();
                        switch (subOpcao) {
                            case 1:
                                cadastroVeiculo.modificar();
                                break;
                            case 2:
                                cadastroPessoa.modificarP();
                                break;
                            case 3:
                                cadastroPessoa.modificarJ();
                                break;
                            default:
                                System.out.println("\nOpção inválida.\n");
                        }
                        break;

                    case 6:
                        System.out.println("Saindo do sistema...\n");
                        break;

                    default:
                        System.out.println("Opção ainda não implementada.\n");
                        break;
                }

            } catch (InputMismatchException o) {
                System.out.println("Entrada inválida! Digite apenas números.\n" + o.getMessage());
                scanf.nextLine(); 
            }
        }
    }
}