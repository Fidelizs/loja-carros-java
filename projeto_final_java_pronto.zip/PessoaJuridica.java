public class PessoaJuridica {
    private String nomeJ;
    private long cnpjJ;

    public PessoaJuridica(String nomeJ, long cnpjJ) {
        this.nomeJ = nomeJ;
        this.cnpjJ = cnpjJ;
    }

    public String getNomeJ() {
        return nomeJ;
    }
    
    public void setNomeJ(String nomeJ){
        this.nomeJ = nomeJ;
    }

    public long getCnpjJ() {
        return cnpjJ;
    }
    
    public void setCnpjJ(long cnpjJ){
        this.cnpjJ = cnpjJ;
    }
    
    @Override
    public String toString() {
        return nomeJ +  " || CNPJ: " + cnpjJ;
    }
}
