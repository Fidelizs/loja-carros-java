public interface Tela {
    void mostrar();

    void modificar();
    
    void listaDeVeiculos();

    void deletar();
    
}

