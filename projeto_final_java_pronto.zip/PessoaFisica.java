public class PessoaFisica {
    private String nomeP;
    private int idadeP;
    private long cpfP;

    public PessoaFisica(String nomeP, int idadeP, long cpfP) {
        this.nomeP = nomeP;
        this.idadeP = idadeP;
        this.cpfP = cpfP;
    }

    public String getNomeP() {
        return nomeP;
    }
    
    public void setNomeP(String nomeP) {
        this.nomeP = nomeP;
    }
    
    public int getIdadeP() {
        return idadeP;
    }
    
    public void setIdadeP(int idadeP) {
        this.idadeP = idadeP;
    }
    
    public long getCpfP() {
        return cpfP;
    }
    
    public void setCpfP(long cpfP) {
        this.cpfP = cpfP;
    }
    
    @Override
    public String toString() {
        return nomeP + "|| Idade: " + idadeP + " || CPF: " + cpfP;
    }
}
