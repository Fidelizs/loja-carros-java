import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;



public class CadastrarPessoa1 implements TelaP {
	private String nomeP, nomeJ;
	private int idadeP, retornar, opcao,subOpcao;
    private long cpfP, cnpjJ;
	Scanner scanf = new Scanner(System.in);
	public ArrayList<PessoaFisica> pessoasFisicas = new ArrayList<>();
	private boolean idadePValida;

	@Override
	public void mostrarP() {
		do {
			boolean dadosValidos = false;

			while (!dadosValidos) {
				try {
                    System.out.println("--------------------------");
                     System.out.println("Você escolheu pessoa física, Confirmar?");
					System.out.println("\n1 - Continuar cadastro.");
					System.out.println("2 - Voltar.");
					System.out.println("--------------------------");
					subOpcao = scanf.nextInt();
					scanf.nextLine();
					System.out.println("\n");


					switch(subOpcao) {

					case 2:
						System.out.println("\nVoltando...\n");
						return;
					case 1:

						System.out.print("Digite seu nome: ");
						nomeP = scanf.nextLine();

						System.out.print("Digite sua idade: ");
						idadeP = scanf.nextInt();
						scanf.nextLine();

						System.out.print("Digite seu CPF:  ");
						cpfP = scanf.nextLong();
						scanf.nextLine();
						System.out.println();

						if(idadeP >= 18) {
							PessoaFisica y = new PessoaFisica (nomeP,idadeP,cpfP);
							pessoasFisicas.add(y);
							dadosValidos = true;
						}  else {
							System.out.print("Cliente precisa ser maior de idade.\n");
						}
					
					break;
				        default:
					System.out.println("Opção invalida\n");
					} 
				} catch (InputMismatchException e) {
					System.out.println("Entrada inválida! Digite apenas números.\n");
					scanf.nextLine();
				} catch (Exception e) {
					System.out.println("Ocorreu um erro: " + e.getMessage() + "\n");

					scanf.nextLine();
				}
			}

			System.out.println("1 - Cadastrar outra Pessoa.");
			System.out.println("2 - Menu principal.");
			System.out.println("Escolha uma opção:\n ");
			System.out.println("-----------------\n");
			retornar = scanf.nextInt();
			scanf.nextLine();

		} while (retornar != 2);
	}


	public void deletarP() {

		if (pessoasFisicas.size() == 0) {
			System.out.println("Nenhuma Pessoa Fisica para deletar.\n");
			return;
		}
		System.out.println("Qual Pessoa Física você gostaria de deletar?\n");
		for (int p = 0; p < pessoasFisicas.size(); p++) {
			System.out.println(p + 1 + " - " + pessoasFisicas.get(p));
		}
		try {
			System.out.println("Escolha uma opção:\n");
			int metodoDeletarP = scanf.nextInt();
			if(metodoDeletarP >= 1 && metodoDeletarP <= pessoasFisicas.size()) {
				pessoasFisicas.remove(metodoDeletarP-1);
				System.out.println("Pessoa Física removida com sucesso.\n");

			} else {
				System.out.println("Opção inválida.\n");
			}

		} catch (InputMismatchException e) {
			System.out.println("Entrada inválida Digite um número.\n");
			scanf.nextLine();
		}
	}

	public void listaDePessoasFisicas() {

		if(pessoasFisicas.size() == 0) {
			System.out.println("\nLista de Pessoas Físicas vazia.\n");
			return;
		}
		System.out.println("0 - Voltar.");
		for (int p = 0; p < pessoasFisicas.size(); p++) {
			System.out.println(p + 1 + " - " + pessoasFisicas.get(p));

		}
		int metodoModificarP = scanf.nextInt();
	}

    public void modificarP() {
    if (pessoasFisicas.size() == 0) {
        System.out.println("Nenhum cliente para editar.\n");
        return;
    }

    System.out.println("Lista de clientes:\n");
    for (int p = 0; p < pessoasFisicas.size(); p++) {
        System.out.println(p + 1 + " - " + pessoasFisicas.get(p));
    }

    System.out.println("Escolha o número do cliente para editar. \n");
    int escolha = scanf.nextInt();
    scanf.nextLine(); 

    if (escolha < 1 || escolha > pessoasFisicas.size()) {
        System.out.println("Opção inválida.\n");
        return;
    }
    
    switch(subOpcao) {
        case 1:
        System.out.println("\nSelecione o dado que deseja editar:\n1 - Nome.\n2 - Idade.\n3 - CPF.\n4 - Voltar.\n");
            subOpcao = scanf.nextInt();
            scanf.nextLine();
            switch(subOpcao){
                case 1:
                PessoaFisica p = pessoasFisicas.get(escolha - 1);
                System.out.print("Digite o novo nome do cliente:");
                String novoNomeP = scanf.nextLine();
                p.setNomeP(novoNomeP);
                System.out.println("Nome do cliente atualizado com sucesso.\n");
                break;
    
                case 2:
                p = pessoasFisicas.get(escolha - 1);
                System.out.print("Digite a nova idade do cliente:");
                int novaIdadeP = scanf.nextInt();
                p.setIdadeP(novaIdadeP);
                System.out.println("Idade do cliente atualizada com sucesso.\n");
                break;
                
                case 3:
                p = pessoasFisicas.get(escolha - 1);
                System.out.print("Digite o novo CPF do cliente:");
                long novoCpfP = scanf.nextLong();
                p.setCpfP(novoCpfP);
                System.out.println("CPF do cliente atualizado com sucesso.\n");
                break;
                  
    
                default:
                System.out.println("\nOpção inválida.\n");
        
            }
        }
    }   

    public ArrayList<PessoaJuridica> pessoasJuridicas = new ArrayList<>();
	@Override
	public void mostrarJ() {
		do {
			boolean dadosValidos = false;

			while (!dadosValidos) {
				try {
                    System.out.println("--------------------------");
                     System.out.println("Você escolheu pessoa Juridica, Confirmar?");
                     
					System.out.println("\n1 - Continuar cadastro:\n");
					System.out.println("2 - Voltar.\n");
					System.out.println("--------------------------");
					subOpcao = scanf.nextInt();
					scanf.nextLine();
					System.out.println("\n");


					switch(subOpcao) {
					case 2:
						System.out.println("\nVoltando...\n");
						return;
					case 1:
						System.out.print("Digite o nome da empresa: ");
						nomeJ = scanf.nextLine();


						System.out.print("Digite o CNPJ: ");
						cnpjJ = scanf.nextLong();
						scanf.nextLine();
						System.out.println();

						PessoaJuridica j = new PessoaJuridica (nomeJ,cnpjJ);
						pessoasJuridicas.add(j);
						dadosValidos = true;

						break;
					default:
						System.out.println("Opção inválida\n");

					}
				}
				catch (InputMismatchException e) {
					System.out.println("Entrada inválida! Digite apenas números.\n");

					scanf.nextLine();
				} catch (Exception e) {
					System.out.println("Ocorreu um erro: " + e.getMessage() + "\n");

					scanf.nextLine();
				}
			}

			System.out.println("1 - Cadastrar outra Empresa.\n");
			System.out.println("2 - Menu principal\n");
			System.out.println("Escolha uma opção:\n ");
			System.out.println("-----------------\n");
			retornar = scanf.nextInt();
			scanf.nextLine();

		} while (retornar != 2);
	}


	public void deletarJ() {

		if (pessoasJuridicas.size() == 0) {
			System.out.println("Nenhuma empresa para deletar.\n");
			return;
		}
		System.out.println("Qual empresa você gostaria de deletar?\n");
		for (int j = 0; j < pessoasJuridicas.size(); j++) {
			System.out.println(j + 1 + " - " + pessoasJuridicas.get(j));
		}

		System.out.println("Escolha uma opção:");
		int metodoDeletarJ = scanf.nextInt();
		if(metodoDeletarJ >= 1 && metodoDeletarJ <= pessoasJuridicas.size()) {
			pessoasJuridicas.remove(metodoDeletarJ-1);
			System.out.println("Empresa removida com sucesso.\n");

		} else {
			System.out.println("Opção inválida.\n");
		}
	}

	public void listaDePessoasJuridicas() {

		if(pessoasJuridicas.size() == 0) {
			System.out.println("\nLista de empresas vazia.\n");
			return;
		}
		System.out.println("0 - Voltar.");
		for (int j = 0; j < pessoasJuridicas.size(); j++) {
			System.out.println(j + 1 + " - " + pessoasJuridicas.get(j));

		}
		int voltar = scanf.nextInt();
	}

    public void modificarJ() {
    if (pessoasJuridicas.size() == 0) {
        System.out.println("Nenhuma empresa para editar.\n");
        return;
    }

    System.out.println("Lista de empresas:\n");
    for (int j = 0; j < pessoasJuridicas.size(); j++) {
        System.out.println(j + 1 + " - " + pessoasJuridicas.get(j));
    }

    System.out.println("Escolha o número da empresa para editar:\n");
    int escolha = scanf.nextInt();
    scanf.nextLine(); 

    if (escolha < 1 || escolha > pessoasJuridicas.size()) {
        System.out.println("Opção inválida.\n");
        return;
    }
    
    switch(subOpcao) {
        case 1:
        System.out.println("\nSelecione o dado que deseja editar:\n1 - Nome.\n2 - CNPJ.\n3 - Voltar.\n");
            subOpcao = scanf.nextInt();
            scanf.nextLine();
            switch(subOpcao){
                case 1:
                PessoaJuridica j = pessoasJuridicas.get(escolha - 1);
                System.out.print("Digite o novo nome da empresa: ");
                String novoNomeJ = scanf.nextLine();
                j.setNomeJ(novoNomeJ);
                System.out.println("Nome da empresa atualizado com sucesso.\n");
                break;
    
                case 2:
                j = pessoasJuridicas.get(escolha - 1);
                System.out.println("Digite o novo CNPJ da empresa: ");
                long novoCnpjJ = scanf.nextLong();
                j.setCnpjJ(novoCnpjJ);
                System.out.println("CNPJ da empresa atualizada com sucesso.\n");
                break;
                
                case 3:
                return;
                    default:
                    System.out.println("\nOpção inválida.\n");
        
                }
            }
        } 
    }
  