import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;



public class CadastrarVeiculo implements Tela {
    private String nome, tipo, marca;
    private int ano, retornar, opcao,subOpcao;
    private float preco;
    private boolean anoValido, precoValido;
    Scanner scanf = new Scanner(System.in);
    public ArrayList<Veiculo> veiculos = new ArrayList<>(); 
 
 
    @Override
    public void mostrar() {
        do {
            boolean dadosValidos = false;

            while (!dadosValidos) {
                try {
                    System.out.println("--------------------------");
                     System.out.println("Você escolheu cadastro de veiculos, Confirmar?");
                    System.out.println("\n1 - Continuar cadastro.");
                    System.out.println("2 - Voltar \n");
                    System.out.println("--------------------------");
                    subOpcao = scanf.nextInt();
                    scanf.nextLine();
                    System.out.println("\n");
                    switch(subOpcao) {

					case 2:
						System.out.println("\nVoltando...\n");
						return;
					case 1:

                    System.out.print("Qual o nome do Veículo? ");
                    nome = scanf.nextLine();
                    
                    System.out.print("Qual a marca do Veículo? ");
                    marca = scanf.nextLine();
                    
                    System.out.print("Qual o ano do Veículo? ");
                    ano = scanf.nextInt();
                    scanf.nextLine();

                    System.out.print("Qual o preço do Veículo? ");
                    preco = scanf.nextFloat();
                    scanf.nextLine();
                    System.out.println();

                    anoValido = setAno(ano, scanf);
                    precoValido = setPreco(preco, scanf);
                
                
                    if (anoValido && precoValido) {
                        
                        Veiculo c = new Veiculo (nome,ano,preco,tipo,marca);
                        veiculos.add(c);
                        dadosValidos = true;
                        System.out.println("Qual o tipo do Veículo?\n");
                        System.out.println("1 - Carro.\n2 - Moto.\n3 - Voltar.\n");
                        subOpcao = scanf.nextInt();
                        System.out.println("\n");
                        scanf.nextLine();
                        switch(subOpcao){
                        case 1:
                        c.setTipo("Carro");
                        break;
                        case 2:
                        c.setTipo("Moto");
                        break;
                        case 3:
                        System.out.print("Voltando...\n");
                        return;
                        default:
                        System.out.println("\nOpção inválida");
                        }
                    
                    } else {
                        System.out.println("\nPor favor, insira os dados corretamente.\n");
                    }
                    break;
                        default:
                        System.out.println("Opção inválida.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Entrada inválida! Digite apenas números.\n");
                  
                    scanf.nextLine();
                } catch (Exception e) {
                    System.out.println("Ocorreu um erro: " + e.getMessage() + "\n");
                   
                    scanf.nextLine();
                }
            }
            
            System.out.println("Veículo Cadastrado com sucesso.");
            System.out.println("--------------------------");
            System.out.println("1 - Cadastrar outro Veículo");
            System.out.println("2 - Menu principal");
            System.out.println("Escolha uma opção:\n ");
            System.out.println("--------------------------");
            retornar = scanf.nextInt();
            scanf.nextLine();
                
            
        } while (retornar != 2);
    }

    public void modificar() {
    if (veiculos.size() == 0) {
        System.out.println("Nenhum Veículo para editar.");
        return;
    }

    System.out.println("Lista de Veículos:\n");
    for (int i = 0; i < veiculos.size(); i++) {
        System.out.println(i + 1 + " - " + veiculos.get(i));
    }

    System.out.println("Escolha o número do Veículo para editar:\n ");
    int escolha = scanf.nextInt();
    scanf.nextLine(); 

    if (escolha < 1 || escolha > veiculos.size()) {
        System.out.println("Índice inválido.\n");
        return;
    }
    
        System.out.println("\nSelecione o dado que deseja editar:\n1 - Nome.\n2 - Marca.\n3 - Ano.\n4 - Preco.\n5 - Tipo.\n6 - Voltar\n");
        subOpcao = scanf.nextInt();
        scanf.nextLine();
        System.out.println("\n");   
            switch(subOpcao) {
        
                case 1:
                Veiculo c = veiculos.get(escolha - 1);
                System.out.print("Digite o novo nome do Veículo: ");
                String novoNome = scanf.nextLine();
                c.setNome(novoNome);
                System.out.println("Nome do Veículo atualizado com sucesso.\n");
                break;
    
                case 2:
                c = veiculos.get(escolha - 1);
                System.out.print("Digite a nova marca do Veículo: ");
                String novaMarca = scanf.nextLine();
                c.setMarca(novaMarca);
                System.out.println("Marca do Veículo atualizado com sucesso.\n");
                break;
                
                case 3:
                c = veiculos.get(escolha - 1);
                System.out.print("Digite o novo ano do Veículo: ");
                int novoAno = scanf.nextInt();
                c.setAno(novoAno);
                System.out.println("Ano do Veículo atualizado com sucesso.\n");
                break;
                
                case 4:
                c = veiculos.get(escolha - 1);
                System.out.println("Digite o novo preço do Veículo: ");
                float novoPreco = scanf.nextFloat();
                c.setPreco(novoPreco);
                System.out.println("Preço do Veículo atualizado com sucesso.\n");
                break;
                
                case 5:
                c = veiculos.get(escolha - 1);
                System.out.println("Escolha o Tipo que será editado:\n");
                System.out.println("1 - Carro.\n2- Moto.\n 3 - Voltar.\n");
                subOpcao = scanf.nextInt();
                scanf.nextLine();
                switch(subOpcao){
                    
                    case 1:
                    c.setTipo("Carro");
                    break;
                    case 2:
                    c.setTipo("Moto");
                    case 3:
                    System.out.println("Voltando...\n");
                    return;
                    default:
                    System.out.println("Opção inválida...\n");
                }
                break;
                case 6:
                System.out.println("Voltando...\n");
                return;
                default:
                System.out.println("\nOpção inválida");
            }
    
        }    
    
    public void deletar() {
        
        if (veiculos.size() == 0) {
        System.out.println("Nenhum Veículo para deletar.\n");
        return;
    }
        System.out.println("Qual Veículo você gostaria de deletar?\n");
        for (int i = 0; i < veiculos.size(); i++) {
            System.out.println(i + 1 + " - " + veiculos.get(i));
        }
        
        System.out.print("Escolha uma opção:");
        int metodoDeletar = scanf.nextInt();
        if(metodoDeletar >= 1 && metodoDeletar <= veiculos.size()){
        veiculos.remove(metodoDeletar-1);
        System.out.println("Carro removido com sucesso.\n");
            
        } else {
        System.out.println("Opção inválida.\n");
        
        }
    } 
  
    public void listaDeVeiculos() {
        
        if(veiculos.size() == 0){
            System.out.println("\nLista de Veículos vazia.\n");
            return;
        }
        System.out.println("0 - Voltar.\n");
        for (int i = 0; i < veiculos.size(); i++) {
            System.out.println(i + 1 + " - " + veiculos.get(i));
        
        }
        int metodoModificar = scanf.nextInt();
    }

    public boolean setAno(int ano, Scanner scanf) {
        if (ano < 2000) {
            System.out.println("Erro! Carro muito antigo para venda.\n");
            
            return false;
        } else if (ano > 2026) {
            System.out.println("Ano indisponível!\n1 - Tente novamente\n2 - Voltar ao menu.\n");
            
            opcao = scanf.nextInt();
            scanf.nextLine();
            System.out.println();
            return opcao != 1;
        } else {
            this.ano = ano;
            return true;
        }
    }

    public boolean setPreco(float preco, Scanner scanf) {
        if (preco < 5000) {
            System.out.println("Erro! Só aceitamos Veículos com o preço a partir de R$ 5.000,00.\n");
            System.out.println("1 - Tente novamente\n2 - Voltar ao menu.\n");
            opcao = scanf.nextInt();
            scanf.nextLine();
            System.out.println();
            return opcao != 1;
        } else {
            this.preco = preco;
            return true;
        }
    }
} 
