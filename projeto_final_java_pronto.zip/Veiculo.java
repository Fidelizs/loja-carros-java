public class Veiculo {
    private String nome, tipo, marca;
    private int ano;
    private float preco;

    public Veiculo(String nome, int ano, float preco, String tipo, String marca) {
        this.nome = nome;
        this.ano = ano;
        this.preco = preco;
        this.tipo = tipo;
        this.marca = marca;
    
    }

    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public int getAno() {
        return ano;
    }
    
    public void setAno(int ano) {
        this.ano = ano;
    }
    
    public float getPreco() {
        return preco;
    }
    
    public void setPreco(float preco) {
        this.preco = preco;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    @Override
    public String toString() {
        return tipo + ": " + nome + " || Marca: " + marca +" || Ano: " + ano + " || Preço: R$ " + String.format("%.2f.", preco);
    }
}
